# Renderiza AÍ

## O universo visual da web, com pitadas de código e cafeína

- **Navigation**

## Actions

---

## Categories

---

[Genres](Genres%2027dc9c9fc305813490a8eec81136defe.csv)

[People](People%2027dc9c9fc30581388228fb80aea23759.csv)

## **Podcasts**

---

[Podcasts & Audiobooks](Podcasts%20&%20Audiobooks%2027dc9c9fc30581f99b13f00b829bd3c4.csv)

## **Podcast** Episodes

---

[Episodes](Episodes%2027dc9c9fc30581f796cbd4aac887a5cc.csv)

# Podcast

<aside>
<img src="Cute_Avatar_2.png" alt="Cute_Avatar_2.png" width="40px" /> **Hello, I'm Edrian**, the creator of this template. If you found this helpful, please leave a rating [here](https://edriansnotes.gumroad.com/l/podcasts).

</aside>